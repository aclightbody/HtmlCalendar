# -*- coding: utf-8 -*-
"""
Created on Thu Aug  6 07:19:30 2020

@author: Andy
"""

# CalendarHtml.py
from CalendarModules.Calendar import Year
from CalendarModules.Calendar import Month
from CalendarModules.Calendar import Day
# from Calendar import Year
# from Calendar import Month
# from Calendar import Day

class HtmlPage:  
   
    def startPage(self):
        startPg = '''
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <style type="text/css">
        table {
            display: inline-block;
            vertical-align: top;
            border-collapse: collapse;
            }
        td {
            border: 1px solid black;
            text-align: center;
        }
        th {
            border: 1px solid black;
            text-align: center;
        }
    </style>
</head>

<body>
<h1 style="text-align:center">Calendar</h1>
'''
        return startPg
    
    def endPage(self):
        endPg = '''
</body>
</html>
'''
        return endPg
    
    def startYear(self, year):
        startYr = '''
<h2 style="text-align:center">''' + year + ''' </h2>
'''
        return startYr
    
    def startTable(self, month):
        startTb = '''
    <table>
    <caption>''' + month + '''<caption/>
    '''
        return startTb
        
    def endTable(self):
        endTb = '''
    </table>
    '''
        return endTb
        
    def startRow(self):
        startRow = '''
        <tr>
        '''
        return startRow
    
    def endRow(self):
        endRow = '''
        </tr>
        '''
        return endRow
        
    def startDay(self):
        startD = '''
            <th>
            '''
        return startD
    
    def endDay(self):
        endD = '''
            </th>
            '''
        return endD
    
    def startCol(self):
        startC = '''
            <td>
            '''
        return startC
    
    def endCol(self):
        endC = '''
            </td>
            '''
        return endC

class Calendar:
    def __init__(self, year):
        self._pageObj = HtmlPage()
        self._dayObj = Day(year)
        self._monthObj = Month(year)

    def _msgDays(self):
        '''
        return (string): html for row containing day names
        '''
        msgDays = ''
        dayList = self._dayObj.getDayList()
        p = self._pageObj
        msgDays += p.startRow()
        for i in dayList:
            msgDays += p.startDay()
            msgDays += i
            msgDays += p.endDay()
        msgDays += p.endRow()
        return msgDays
    
    def _msgMonthList(self, month):
        '''
        month (string): month input
        return (list): list of all the date numbers associated to the day for each month
        '''
        dDict = self._dayObj.getFirstDayOfMonth()
        dayList = self._dayObj.getDayList()
        monthData = self._monthObj.getMonthData()
        dIdx = dayList.index(dDict[month])
        mList = [''] * dIdx

        for i in range(1, int(monthData[month]) + 1):
            mList.append(str(i))
        
        endNum = len(dayList) - (dIdx + int(monthData[month])) % len(dayList)
        if endNum < len(dayList):
            mList += [''] * endNum
        return mList
        
    
    def msgMonths(self):
        '''
        return (string): html for months in the year
        '''
        msgMonths = ''
        p = self._pageObj
        dDict = self._dayObj.getFirstDayOfMonth()
        msgDays = self._msgDays()
        dayList = self._dayObj.getDayList()
        
        for k, v in dDict.items():
            msgMonths += p.startTable(k)
            msgMonths += msgDays
            mList = self._msgMonthList(k)
            for i in range(len(mList)):
                if i == 0:
                    msgMonths += p.startRow()
                elif i % len(dayList) == 0 and i != 0:
                    msgMonths += p.endRow()
                    msgMonths += p.startRow()
                msgMonths += p.startCol()
                msgMonths += mList[i]
                msgMonths += p.endCol()
            msgMonths += p.endRow()
            msgMonths += p.endTable()
        return msgMonths
