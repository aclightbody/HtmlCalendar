# -*- coding: utf-8 -*-
"""
Created on Sun Aug  9 15:05:48 2020

@author: Andy
"""

from CalendarModules.Calendar import Year
from CalendarModules.Calendar import Month
from CalendarModules.Calendar import Day

def yearInitTest():
    print('Year init test')
    yearList = [('a', False), ('1500', False), ('2000', True)]
    for y in yearList:
        try:
            yearTest = Year(y[0])
            assert y[1] == yearTest._inputPass
            print("'" + str(y[0]) + "'" + ' input: PASS')
            
            # print('Is ' + str(yearNum) + ' leap: ' + str(yearTest.isLeapYear()))
        except:
                print("'" + str(y[0]) + "'" + ' input: FAIL')   
    print('\n')
    
yearInitTest()

def getYearTest():
    print('Get year test')
    yearList = [('2000', '2000')]
    for y in yearList:
        try:
            yearTest = Year(y[0])
            assert y[1] == yearTest.getYear()
            print("'" + str(y[0]) + "'" + ' input: PASS')
            
            # print('Is ' + str(yearNum) + ' leap: ' + str(yearTest.isLeapYear()))
        except:
                print("'" + str(y[0]) + "'" + ' input: FAIL') 
    print('\n')
        
getYearTest()

def isLeapYearTest():
    print('Is leap year test')
    yearList = [ ('2000', True), ('2004', True), ('2005', False), ('1600', True), ('1700', False), ('1702', False), ('1704', True)]
    for y in yearList:
        try:
            yearTest = Year(y[0])
            
            if y[1]:
                isLeap = 'leap'
            else:
                isLeap = 'not leap'
                
            assert yearTest.isLeapYear(y[0]) == y[1]        
                
            print("'" + str(y[0]) + "' is " + isLeap + ' year: PASS')
        except:
            print("'" + str(y[0]) + "' is " + isLeap + ' year: FAIL')
    print('\n')
    
isLeapYearTest()

def preveNumLeapYearsTest():
    print('Number of leap years test')
    yearList = [ ('2000', True, 101 ), ('2004', True, 102), ('2005', False, 103), ('1600', True, 4), ('1700', False, 29), ('1702', False, 29), ('1704', True, 29)]
    for y in yearList:
        try:
            yearTest = Year(y[0])
            
            if y[1]:
                isLeap = 'leap'
            else:
                isLeap = 'not leap'
                
            assert yearTest.getPrevNumLeapYears()   == y[2]
                
            print("'" + str(y[0]) + "' is " + isLeap + ' year: PASS')
        except:
            print("'" + str(y[0]) + "' is " + isLeap + ' year: FAIL')
    print('\n')
    
preveNumLeapYearsTest()

def leapMonthTest():
    print('Leap month test')
    yearList = [('1702', '28'), ('1704', '29')]
    for y in yearList:
        try:
            monthTest = Month(y[0])
            monthData = monthTest.getMonthData()
            
            if monthTest._yearObj.isLeapYear(y[0]):
                isLeap = 'leap'
            else:
                isLeap = 'no leap'
                
            assert monthData['Feb'] == y[1]        
                
            print("'" + str(y[0]) + "' has " + isLeap + ' month: PASS')
        except:
            print("'" + str(y[0]) + "' has " + isLeap + ' month: FAIL')
    print('\n')
    
leapMonthTest()

def firstDayOfYearTest():
    print('First day of year test')
    yearList = [ ('2000', 'Sat' ), ('2001', 'Mon'), ('2002', 'Tue'), ('2003', 'Wed'), ('2004', 'Thu'), ('2005', 'Sat'), ('1800', 'Wed'), ('1900','Mon'), ('2017', 'Sun')]
    for y in yearList:
        try:
            dayTest = Day(y[0])
            assert dayTest.getFirstDayOfYear()  == y[1]
                
            print("'" + str(y[0]) + "' first day expected " + y[1] + ' actual is ' + dayTest.getFirstDayOfYear() + ': PASS')
        except:
            print("'" + str(y[0]) + "' first day expected " + y[1] + ' actual is ' + dayTest.getFirstDayOfYear() + ': FAIL')
    print('\n') 
    
firstDayOfYearTest()

def firstDayOfMonthTest():
    print('First day of each month test')
    yearList = [ ('2000', {'Jan':'Sat', 'Feb':'Tue', 'Mar':'Wed', 'Apr':'Sat', 'May':'Mon', 'Jun':'Thu', 'Jul':'Sat', 'Aug':'Tue', 'Sep':'Fri', 'Oct':'Sun', 'Nov':'Wed', 'Dec':'Fri'})]
    for y in yearList:
            dayTest = Day(y[0])
            dayMonth = dayTest.getFirstDayOfMonth()
            for k, v in y[1].items():
                try:
                    assert dayMonth[k]  == y[1][k]
                    print("'" + str(y[0]) + "' " + k + " first day expected " + v + ' actual is ' + dayMonth[k] + ': PASS')
                except:
                    print("'" + str(y[0]) + "' " + k + " first day expected " + v + ' actual is ' + dayMonth[k] + ': FAIL')
    print('\n') 
    
firstDayOfMonthTest()
    
    
    