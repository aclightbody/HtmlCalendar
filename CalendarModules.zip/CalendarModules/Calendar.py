# -*- coding: utf-8 -*-
"""
Created on Sat Aug  8 11:25:20 2020

@author: Andy
"""

class Year:
    def __init__(self, year):
        '''
        year: int (e.g. 2000)
        '''
        self._firstGregorianYear = '1583'
        self._inputPass = True
        try:
            yearTemp = int(year)
            if not yearTemp > 1582:
                raise ValueError
            
            self._year = year
        except ValueError:
            self._inputPass = False
            print('Value Error: Input needs to be integer greater than 1582, e.g. 2000')

        # assert (type(int(year)) == int), 'Input needs to be integer greater than 1582, e.g. 2000'
        # assert int(year) > 1582, 'Input needs to be integer greater than 1582, e.g. 2000'
        
        # self._year = int(year)
        
        
    def getYear(self):
        '''
        return (string): year
        '''
        return self._year
    
    def getFirstGregYear(self):
        '''
        return (string): returns first full Gregorian calendar year
        '''
        return self._firstGregorianYear
    
    def isLeapYear(self, year):
        '''
        year (string): year
        
        return (boolean): True if year is leap year, False if not
    
        To be a leap year: 
            - Needs to be divisble by 4.
            - If it is divisible by 100, then also needs to be divisible by 400.
        '''
        year = int(year)
        if not year % 4:
            if year >= 400 and not year % 100:
                if not year % 400:
                    return True # if divisible by 4, 100, 400
                else:
                    return False # if divisislbe by 4, 100, but not 400
            return True # if divislbe by 4, but not divisible by 100
        return False # if not divisible by 4
    
    def getPrevNumLeapYears(self):
        '''
        return (int): returns previous number of leap years to the specified year
        '''
        numLeapYear = 0
        firstYear = int(self.getFirstGregYear())
        currentYear = int(self.getYear())
        
        for i in range(firstYear, currentYear):
            if self.isLeapYear(i):
                numLeapYear += 1
        return numLeapYear

        
class Month:
    def __init__(self, year):
        '''
        year: int, 4 digits (e.g. 2000)
        '''
        
        self._yearObj = Year(year)
        self._firstGregorianDate = [
            {
                'm':'Jan',
                'n':'1'
            }
            ]
        self._monthData = {
            'Jan':'31',
            'Feb':'28',
            'Mar':'31',
            'Apr':'30',
            'May':'31',
            'Jun':'30',
            'Jul':'31',
            'Aug':'31',
            'Sep':'30',
            'Oct':'31',
            'Nov':'30',
            'Dec':'31'
             }

        
        if self._yearObj.isLeapYear(year):
            self._monthData['Feb'] = '29'
            
    def getMonthData(self):
        '''
        return (dict): retuns a dictionary copy of the number of days in each 
        month of the specified year
        '''
        return self._monthData.copy()
                
class Day:
    def __init__(self, year):
        self._yearObj = Year(year)
        self._monthObj = Month(year)
        self._firstGregorianDay ='Sat'
        self._dayList = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        self._daysYear = 365
        self._firstDayOfWeek = 'Mon'
        
    def getDayList(self):
        '''
        return (list): returns list of days in a week
        '''
        return self._dayList[:]
        
    def getPrevNumDays(self):
        '''
        return (int): Gets number of days from 1st Jan 1583 to 1st Jan of selected year
        '''
        currentYear = int(self._yearObj.getYear())
        baseYear = int(self._yearObj.getFirstGregYear())
        diffYear = currentYear - baseYear
        prevNumLeapYears = self._yearObj.getPrevNumLeapYears()
        numDay = diffYear * self._daysYear + prevNumLeapYears # adding on leap year days (prevNumLeapYears)
        return numDay
  
    def getFirstDayOfYear(self):
        '''
        return (string): returns first day of specified year
        '''
        numDay = self.getPrevNumDays()
        dayList = self.getDayList()
        dayDiffIndex = numDay % len(dayList)
        firstGregDayIndex = dayList.index(self._firstGregorianDay)
        firstDayIndex = (firstGregDayIndex + dayDiffIndex) % len(dayList)
        firstDay = dayList[firstDayIndex]
        return firstDay
    
    def _firstDayOfMonth(self):
        '''
        return (dict): returns dictionary of the first day for all months in
        specified year
        '''
        dDict = {}
        monthData = self._monthObj.getMonthData()
        dayList = self.getDayList()
        firstDayYear = self.getFirstDayOfYear()
        
        for k, v in monthData.items():
            if not dDict:
                dDict[k] = firstDayYear
                lastKey = k
            else:
                firstDayMonIdx = (dayList.index(dDict[lastKey]) + int(monthData[lastKey])) % len(dayList)
                dDict[k] = dayList[firstDayMonIdx]
                lastKey = k
        return dDict
    
    def getFirstDayOfMonth(self):
        '''
        return (dict): returns a dictionary copy of the first day for all the 
        months in specified year
        '''
        return self._firstDayOfMonth().copy()
     
                
        
        
        
                

        