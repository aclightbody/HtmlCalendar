# -*- coding: utf-8 -*-
"""
Created on Thu Aug  6 07:19:30 2020

@author: Andy
"""

# CalendarHtml.py

import webbrowser
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))

f = open('Calendar.html','w') # 'w' = write
a = '1'

table = '''
<table>
    <caption>Month<caption/>
    <tr>
        <th>Mo</th>
        <th>Tu</th>
        <th>We</th>
        <th>Th</th>
        <th>Fr</th>
        <th>Sa</th>
        <th>Su</th>
    </tr>
    <tr>
        <td>
         ''' + a  + ''' 
        </td>
        <td></td>
        <td></td>
        <td>4</td>
        <td>5</td>
        <td>6</td>
        <td>7</td>
    </tr>
</table>
'''

# dir="ltr" direction left-to-right
# text/css helps utlilise the vertical-align property for table columns when using inline-block attribute
message = """
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <style type="text/css">
        table {
            display: inline-block;
            vertical-align: top;
            border-collapse: collapse;
            }
        td {
            border: 1px solid black;
            text-align: center;
        }
        th {
            border: 1px solid black;
            text-align: center;
        }
    </style>
</head>

<body>
<h1 style="text-align:center">Year</h1>
""" + table*12 + """

</body>
</html>
"""

# origMsg = """
# <!DOCTYPE html>
# <html>
# <head>
# <style>
#     table, th, td {
#         border: 1px solid black;
#         border-collapse: collapse;
#         margin-left:auto;
#         margin-right:auto;
#         }
#     td {
#         padding: 5px;
#         text-align: left;
#         }
#     th {
#         padding: 5px;
#         text-align: center;
#         }
# </style>
# </head>

# <body>
# <h1 style="text-align:center">Calendar</h1>
# """ + table*12 + """

# </body>
# </html>
# """

f.write(message)
f.close()

# filename = dir_path + "\\" + 'helloworld.html' # need \\ to insert \ since \ is a special string char
webbrowser.open_new_tab('Calendar.html')


