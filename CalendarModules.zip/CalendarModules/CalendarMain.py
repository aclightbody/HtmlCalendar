#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug  8 11:49:26 2020

@author: Andy
"""

import webbrowser
import os 
from CalendarModules.CalendarHtml import Calendar
from CalendarModules.CalendarHtml import HtmlPage
import sys

def CalMain(year='2000', filename='Calendar'):
    '''
    Creates html file and web page containing Gregorian calendar for specified
    year and for the year before and after the specified year. Example input: CalMain('2000', 'Year 2000 Calendar').
    
    year (string):  integer year above 1583.
    
    filename (string): name of output html file.
    
    returns: html file in current directory and opens web page.
    '''
    dir_path = os.path.dirname(os.path.realpath(__file__))
    
    try:
        yearTemp = int(year)
        if not yearTemp > 1582:
            raise ValueError
            
        fname = dir_path + "\\" + filename + '.html' # need \\ to insert \ since \ is a special string char
        f = open(fname,'w') # 'w' = write
        # f = open(filename + '.html','w') # 'w' = write, directly writes to directory of module
       
        
        yRange = [str(i) for i in range(int(year) - 1,int(year) + 2)]
        p = HtmlPage()
        msg = ''
        
        msg += p.startPage()
    
        for y in yRange:
            msg += p.startYear(y)    
            c = Calendar(y)
            msgM = c.msgMonths()
            msg += msgM
        msg += p.endPage()
        
        f.write(msg)
        f.close()
        
        webbrowser.open_new_tab(fname)
        
    except ValueError:
        print('Value Error: year input needs to be a string of integer greater than 1582, e.g. "2000"')
        
    except TypeError:
        print('Type Error: filename needs to be a string')

# Comment the below out to run in IDE
if __name__ == '__main__':
    CalMain(sys.argv[1]) # The 0th arg is the module filename.

# CalMain('a','a')
# CalMain('1','a')
# CalMain(2000,'a')
# CalMain('2000',1)
# CalMain('1800', 'Year1800')
# CalMain('1900', 'Year1900')
# CalMain('2000', 'Year2000')
# CalMain('2017', 'Year2017')
# CalMain()


                       